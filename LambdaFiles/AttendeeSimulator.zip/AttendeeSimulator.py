import datetime
import random
import os
import json
import boto3
from boto3.dynamodb.conditions import Key
from ListUsers import Users  # Importando o dicionário Users (email: nome)
import decimal
import time


# Configurar cliente do DynamoDB
dynamodb = boto3.resource('dynamodb')

# Obter o nome da tabela a partir da variável de ambiente
table_name = os.getenv('AWS_DYNAMODB_TABLE_TARGET_NAME_0')
if not table_name:
    raise ValueError(
        "A variável de ambiente 'AWS_DYNAMODB_TABLE_TARGET_NAME_0' não foi definida.")

table = dynamodb.Table(table_name)

org_name = "PythonFloripa"
event_title = "PythonFloripa1"
sort_key_prefix = "$"  # Prefixo para a chave de ordenação

# Inicialização de clientes AWS fora do handler (melhor prática)
region = os.getenv("AWS_DYNAMODB_TABLE_TARGET_REGION_0")
COGNITO_PARAM_NAME = os.getenv("AWS_SSM_PARAMETER_SOURCE_NAME_0")
COGNITO_PARAM_REGION = os.getenv("AWS_SSM_PARAMETER_SOURCE_REGION_0")

ssm = boto3.client('ssm', region_name=region)
cognito_client = boto3.client('cognito-idp', region_name=COGNITO_PARAM_REGION)

print("COGNITO_PARAM_NAME", COGNITO_PARAM_NAME)

# Recupera parâmetros do Cognito do SSM Parameter Store
response = ssm.get_parameter(Name=COGNITO_PARAM_NAME, WithDecryption=True)
json_data = json.loads(response['Parameter']['Value'])

user_pool_id = ""
client_id = ""
client_secret = ""
main_domain = ""

for item in json_data:
    if item['ResourceType'] == "aws_cognito_user_pool_client":
        client_id = item['id']
        client_secret = item.get('client_secret', '')
    elif item['ResourceType'] == "aws_cognito_user_pool":
        user_pool_id = item['id']
    elif item['ResourceType'] == "aws_route53_zone":
        main_domain = item['Domain']

if not user_pool_id:
    raise ValueError(
        "O user_pool_id não foi encontrado nos parâmetros do Cognito.")


def get_last_event():
    """Busca o último evento na tabela DynamoDB que contém a chave 'date'."""
    response = table.query(
        KeyConditionExpression=Key('Partition').eq(org_name),
        ScanIndexForward=False,  # Ordena do mais recente para o mais antigo
        Limit=10  # Aumenta o limite para procurar itens válidos
    )
    for item in response["Items"]:
        if "date" in item:
            return item
    return None


def generate_next_date(last_date):
    """Gera a próxima data baseada na última data encontrada, no formato YYYY-MM-DD."""
    last_date_obj = datetime.datetime.strptime(last_date, "%Y-%m-%d")
    next_date_obj = last_date_obj + datetime.timedelta(days=1)
    return next_date_obj.strftime("%Y-%m-%d")


def get_sub_id_by_email(email):
    """Obtém o sub_id do Cognito para um dado email."""
    try:
        response = cognito_client.admin_get_user(
            UserPoolId=user_pool_id,
            Username=email
        )
        # O atributo 'sub' está nos atributos do usuário
        for attr in response['UserAttributes']:
            if attr['Name'] == 'sub':
                return attr['Value']
        raise ValueError(f"'sub' não encontrado para o usuário {email}.")
    except cognito_client.exceptions.UserNotFoundException:
        raise ValueError(
            f"Usuário com email {email} não encontrado no Cognito.")
    except Exception as e:
        raise e


def verify_users_in_cognito(users):
    """Verifica se todos os usuários do dicionário Users existem no Cognito."""
    cognito_users = []
    paginator = cognito_client.get_paginator('list_users')
    for page in paginator.paginate(UserPoolId=user_pool_id):
        for user in page['Users']:
            for attr in user['Attributes']:
                if attr['Name'] == 'email':
                    cognito_users.append(attr['Value'])
    missing_users = [email for email in users.keys() if email not in cognito_users]
    if missing_users:
        print(f"Usuários faltando no Cognito: {missing_users}")
    else:
        print("Todos os usuários existem no Cognito.")
    return missing_users


def check_users_dict(users):
    """Verifica se o dicionário Users está correto."""
    if not isinstance(users, dict):
        raise ValueError("Users deve ser um dicionário.")
    for email, name in users.items():
        if not isinstance(email, str) or not isinstance(name, str):
            raise ValueError(f"Formato inválido para usuário: {email}: {name}")
    print(f"{len(users)} usuários verificados no dicionário Users.")


def put_item_with_retry(table, item, max_retries=3, backoff_factor=0.5):
    """Insere um item no DynamoDB com retry em caso de falha."""
    for attempt in range(max_retries):
        try:
            table.put_item(Item=item)
            print(f"Attendee inserido: {item}")  # Log para depuração
            return True
        except Exception as e:
            print(f"Erro ao inserir attendee {item['Email']}: {e}")
            if attempt < max_retries - 1:
                sleep_time = backoff_factor * (2 ** attempt)
                print(f"Retryando em {sleep_time} segundos...")
                time.sleep(sleep_time)
            else:
                print(f"Falha ao inserir attendee {item['Email']} após {max_retries} tentativas.")
                return False


def create_event(org_name, event_title):
    """Cria um novo evento no DynamoDB."""
    last_event = get_last_event()
    print(f"Último evento recuperado: {last_event}")  # Log adicional para depuração

    if last_event:
        last_date = last_event.get("date")  # Utiliza .get() para evitar KeyError
        if last_date:
            # Extrair a última data e gerar a próxima
            new_event_date = generate_next_date(last_date)
            try:
                last_event_number = int(
                    last_event["title"].split(" ")[-1])  # Extrai número do título
            except (IndexError, ValueError):
                last_event_number = 0
            new_event_number = last_event_number + 1
        else:
            # Se 'date' não existir, utiliza a data atual
            new_event_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
            new_event_number = 1
            print("A chave 'date' não foi encontrada no último evento. Usando a data atual.")
    else:
        # Se não houver eventos, utiliza a data atual
        new_event_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        new_event_number = 1
        print("Nenhum evento anterior encontrado. Usando a data atual.")

    new_event_title = f"{event_title}{new_event_number}"

    # Criar entrada no DynamoDB
    item = {
        "Partition": org_name,  # Nome correto da chave de partição
        "Sort": f"{sort_key_prefix}{new_event_date}",  # Nome correto da chave de ordenação
        "title": new_event_title,
        "date": new_event_date,
    }
    table.put_item(Item=item)
    print(f"Evento criado: {item}")  # Log para depuração

    return {
        "statusCode": 200,
        "body": f"Novo evento criado: {new_event_title} na data {new_event_date}"
    }


def insert_event(org_name, event_title, number_of_attendees):
    """Insere itens na tabela DynamoDB com as informações especificadas."""
    # Criar o evento principal
    create_event(org_name, event_title)

    # Calcular o TTL para 1 dia a partir do momento atual
    ttl = int((datetime.datetime.utcnow() +
              datetime.timedelta(days=1)).timestamp())

    # Inicializar contadores
    success_count = 0
    skip_count = 0

    # Criar attendees
    for i in range(number_of_attendees):
        attendee_email = random.choice(list(Users.keys()))
        attendee_name = Users[attendee_email]

        # Obter o sub_id do attendee a partir do Cognito
        try:
            attendee_sub_id = get_sub_id_by_email(attendee_email)
        except ValueError:
            print(f"Usuário com email {attendee_email} não encontrado no Cognito.")
            skip_count += 1
            continue  # Pula se o usuário não for encontrado no Cognito
        except Exception as e:
            print(f"Erro ao obter sub_id para {attendee_email}: {e}")
            skip_count += 1
            continue  # Pula em caso de outras exceções

        attendee_sort_key = f"#:{event_title}:{attendee_sub_id}"

        attendee_item = {
            "Partition": org_name,             # Nome da organização como chave de partição
            "Sort": attendee_sort_key,         # Título do evento e subID como chave de ordenação
            "Name": attendee_name,             # Nome do participante
            "Email": attendee_email,           # Email do participante
            "HasImage": False,                 # Atributo booleano
            "IsSent": False,                   # Atributo booleano
            "TTL": ttl                         # Time to Live (1 dia)
        }

        # Inserir o item do attendee na tabela DynamoDB com retry
        success = put_item_with_retry(table, attendee_item)
        if success:
            success_count += 1
        else:
            skip_count += 1

    # Informar o resultado
    print(f"Inserção concluída: {success_count} inseridos, {skip_count} pulados.")

    return {
        "statusCode": 200,
        "body": f"Evento e {success_count} attendees inseridos com sucesso: {event_title}. {skip_count} attendees foram pulados devido a erros."
    }


def lambda_handler(event, context):
    """Função Lambda principal."""
    try:
        # Verificar a estrutura do dicionário Users
        check_users_dict(Users)

        # Verificar se todos os usuários existem no Cognito
        missing_users = verify_users_in_cognito(Users)
        if missing_users:
            raise ValueError(f"Os seguintes usuários não existem no Cognito: {missing_users}")

        # Extrair parâmetros do evento (ajuste conforme a estrutura do seu evento)
        number_of_attendees = event.get("number_of_attendees", 10)  # Mover para dentro do handler

        # Validação adicional
        if not isinstance(number_of_attendees, int) or number_of_attendees < 0:
            raise ValueError("`number_of_attendees` deve ser um inteiro positivo.")

        result = insert_event(org_name, event_title, number_of_attendees)
        return result
    except ValueError as ve:
        print(f"Erro de valor: {str(ve)}")  # Log para depuração
        return {
            "statusCode": 400,  # Bad Request
            "body": f"Erro de valor: {str(ve)}"
        }
    except Exception as e:
        print(f"Erro inesperado: {str(e)}")  # Log para depuração
        return {
            "statusCode": 500,
            "body": f"Erro inesperado: {str(e)}"
        }
