import os
import json
import boto3
from boto3.dynamodb.conditions import Key
import decimal

# Obter variáveis de ambiente
table_name = os.getenv('AWS_DYNAMODB_TABLE_TARGET_NAME_0')
queue_url = os.getenv('AWS_SQS_QUEUE_TARGET_NAME_0')
if not queue_url:
    raise ValueError(
        "A variável de ambiente 'SQS_QUEUE_URL' não está definida.")

# Inicializa os recursos do DynamoDB e do SQS
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(table_name)
sqs = boto3.client('sqs')


def lambda_handler(event, context):
    # Obter a variável de ação do evento
    action = event.get('Action')
    if action != "StartCreateCerts":
        message = f"Ação '{action}' não é suportada. Nenhuma operação será realizada."
        print(message)
        return {
            "statusCode": 200,
            "body": message
        }

    # Extrair OrgName e EventName do evento
    org_name = event.get('OrgName')
    event_name = event.get('EventName')

    # Validar se OrgName e EventName estão presentes no evento
    if not org_name or not event_name:
        raise ValueError(
            "Os campos 'OrgName' e 'EventName' são obrigatórios no evento.")

    # Construir o prefixo para a chave de ordenação (Sort Key)
    sort_key_prefix = f"#:{event_name}:"

    # Realiza a consulta no DynamoDB
    response = table.query(
        KeyConditionExpression=Key('Partition').eq(
            org_name) & Key('Sort').begins_with(sort_key_prefix),
        ScanIndexForward=True  # Ordena do mais antigo para o mais recente
    )
    items = response.get('Items', [])
    items_converted = convert_decimals(items)

    # Conta a quantidade de entradas lidas
    attendee_counter = len(items_converted)

    # Inserir no DynamoDB o contador de entradas
    counter_item = {
        'Partition': org_name,
        'Sort': f"%{event_name}",
        'AttendeeCounter': attendee_counter
    }
    table.put_item(Item=counter_item)

    # Envia mensagem para a SQS para cada participante
    for item in items_converted:
        # Extrair o subid da Sort Key
        sort_key = item.get('Sort', '')
        subid = sort_key.split(':')[2]

        message = {
            'OrgName': org_name,
            'EventName': event_name,
            'AttendeeName': item.get('Name', '').encode('utf-8').decode('utf-8'),
            'AttendeeEmail': item.get('Email', ''),
            'SubID': subid
        }

        # Envia a mensagem para a fila SQS
        sqs.send_message(QueueUrl=queue_url, MessageBody=json.dumps(
            message, ensure_ascii=False))

    print(
        f"Itens encontrados para OrgName='{org_name}' e EventName='{event_name}':")
    for item in items_converted:
        print(json.dumps(item, ensure_ascii=False))

    return {
        "statusCode": 200,
        "body": json.dumps({
            "AttendeeCounter": attendee_counter,
        }, ensure_ascii=False)
    }


def convert_decimals(obj):
    if isinstance(obj, list):
        return [convert_decimals(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: convert_decimals(v) for k, v in obj.items()}
    elif isinstance(obj, decimal.Decimal):
        if obj % 1 == 0:
            return int(obj)
        else:
            return float(obj)
    else:
        return obj
