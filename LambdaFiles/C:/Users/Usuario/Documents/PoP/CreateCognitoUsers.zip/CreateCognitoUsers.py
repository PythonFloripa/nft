import boto3
import os
import json
from ListUsers import Users  # Importando o dicionário Users

# Inicialização de clientes AWS fora do handler (melhor prática)
region = os.getenv("AWS_DYNAMODB_TABLE_TARGET_REGION_0")
COGNITO_PARAM_NAME = os.getenv("AWS_SSM_PARAMETER_SOURCE_NAME_0")
COGNITO_PARAM_REGION = os.getenv("AWS_SSM_PARAMETER_SOURCE_REGION_0")

ssm = boto3.client('ssm', region_name=region)
cognito_client = boto3.client('cognito-idp', region_name=COGNITO_PARAM_REGION)

# Recupera parâmetros do Cognito do SSM Parameter Store
response = ssm.get_parameter(Name=COGNITO_PARAM_NAME, WithDecryption=True)
json_data = json.loads(response['Parameter']['Value'])

user_pool_id = ""
client_id = ""
client_secret = ""
main_domain = ""

for item in json_data:
    if item['ResourceType'] == "aws_cognito_user_pool_client":
        client_id = item['id']
        client_secret = item.get('client_secret', '')
    elif item['ResourceType'] == "aws_cognito_user_pool":
        user_pool_id = item['id']
    elif item['ResourceType'] == "aws_route53_zone":
        main_domain = item['Domain']

# Função para adicionar usuários ao Cognito


def add_users_to_cognito(users):
    for email, name in users.items():
        try:
            response = cognito_client.admin_create_user(
                UserPoolId=user_pool_id,
                Username=email,
                UserAttributes=[
                    {'Name': 'email', 'Value': email},
                    {'Name': 'name', 'Value': name},
                    # Define o e-mail como verificado
                    {'Name': 'email_verified', 'Value': 'true'}
                ],
                MessageAction='SUPPRESS'  # Evita o envio automático de e-mails pelo Cognito
            )
            print(
                f"Usuário {name} ({email}) adicionado com sucesso ao Cognito.")
        except Exception as e:
            print(f"Erro ao adicionar o usuário {name} ({email}): {str(e)}")

# Handler da Lambda


def lambda_handler(event, context):
    """
    Função handler da AWS Lambda.
    """
    try:
        # Adiciona os usuários do dicionário ao Cognito
        add_users_to_cognito(Users)
        return {
            'statusCode': 200,
            'body': json.dumps("Usuários adicionados ao Cognito com sucesso!")
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Erro ao adicionar usuários ao Cognito: {str(e)}")
        }
