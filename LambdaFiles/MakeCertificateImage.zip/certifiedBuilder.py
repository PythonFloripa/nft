from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
import boto3

# Configuração do bucket e fontes


class CertifiedBuilder:
    def __init__(self,):
        self.FONT_NAME_PATH = "fonts/PinyonScript/PinyonScript-Regular.ttf"
        self.VALIDATION_CODE_PATH = "fonts/ChakraPetch/ChakraPetch-SemiBold.ttf"

    def generate_certificate(self, participant, certificate_template: Image, font_name_data, font_validation_data):
        """
        Gera o certificado com base nos dados do participante e no template.
        """
        font_name = ImageFont.truetype(font_name_data, 70)
        font_validation = ImageFont.truetype(font_validation_data, 20)

        name_image = self.create_name_image_layer(
            participant.name_completed(), certificate_template.size, font_name)
        validation_code_image = self.create_validation_code_image(
            participant.formated_validation_code(), certificate_template.size, font_validation)

        name_image.paste(validation_code_image, (0, 0), validation_code_image)
        certificate_template.paste(name_image, (0, 0), name_image)
        return certificate_template

    def create_name_image_layer(self, name: str, size: tuple, font: ImageFont) -> Image:
        """Cria uma camada de imagem com o nome do participante."""
        name_image = Image.new("RGBA", size, (255, 255, 255, 0))
        draw = ImageDraw.Draw(name_image)
        position = self.calculate_text_position(name, font, draw, size)
        draw.text(position, name, fill=(0, 0, 0), align="center", font=font)
        return name_image

    def calculate_text_position(self, text: str, font: ImageFont, draw: ImageDraw, size: tuple) -> tuple:
        """Calcula a posição do texto centralizado."""
        text_bbox = draw.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        position = ((size[0] - text_width) / 2, (size[1] - text_height) / 2)
        return position

    def create_validation_code_image(self, validation_code: str, size: tuple, font: ImageFont) -> Image:
        """Cria uma camada de imagem com o código de validação."""
        validation_code_image = Image.new("RGBA", size, (255, 255, 255, 0))
        draw = ImageDraw.Draw(validation_code_image)
        position = self.calculate_validation_code_position(
            validation_code, font, draw, size)
        draw.text(position, validation_code, fill=(
            0, 0, 0), align="center", font=font)
        return validation_code_image

    def calculate_validation_code_position(self, validation_code: str, font: ImageFont, draw: ImageDraw, size: tuple) -> tuple:
        """Calcula a posição do código de validação no rodapé."""
        text_bbox = draw.textbbox((0, 0), validation_code, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        position = (size[0] - text_width - 50, size[1] - text_height - 40)
        return position

    def create_name_file(self, participant) -> str:
        """Cria o nome do arquivo para salvar o certificado."""
        return "{}_{}_{}.png".format(
            participant.name_completed(),
            participant.validation_code,
            participant.event_name
        )
