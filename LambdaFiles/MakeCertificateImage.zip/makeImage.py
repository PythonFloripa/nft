import os
import boto3
from PIL import Image, ImageDraw
from io import BytesIO

from certifiedBuilder import CertifiedBuilder
from participant import Participant


def upload_to_s3(img, bucket_name, file_name, s3_client):
    """
    Faz upload de uma imagem para o bucket S3.
    :param img: Objeto Pillow Image.
    :param bucket_name: Nome do bucket S3.
    :param file_name: Nome do arquivo a ser salvo no bucket.
    """
    # Converter imagem em bytes
    img_bytes = BytesIO()
    img.save(img_bytes, format='PNG')
    img_bytes.seek(0)

    # Upload para o S3
    s3_client.upload_fileobj(img_bytes, bucket_name, file_name)


def fetch_certificate_template_from_s3(bucket_name, object_key, s3_client):

    object_key = "templates/{}".format(object_key)

    # Faz o download do objeto diretamente na memória
    response = s3_client.get_object(Bucket=bucket_name, Key=object_key)

    file_content = response['Body'].read()

    # Abre a imagem na memória
    img = Image.open(BytesIO(file_content))

    # Retorna a imagem para uso no código
    return img


def fetch_font_from_s3(bucket_name, object_key, s3_client):
    """
    Busca uma fonte no S3 e retorna um objeto ImageFont.
    """
    response = s3_client.get_object(Bucket=bucket_name, Key=object_key)

    font_data = BytesIO(response['Body'].read())

    return font_data


def makeImage(OrgName, EventName, AttendeeName, bucket_certificate_name, bucket_template_name, s3):
    """
    Função Lambda handler.
    """
    try:
        # Criação do participante a partir do evento
        participant = Participant(AttendeeName, EventName)

        # Busca o template do certificado no S3
        certificate_template = fetch_certificate_template_from_s3(
            bucket_certificate_name, bucket_template_name, s3)

        # Instancia o gerador de certificados
        certified_builder = CertifiedBuilder()

        # Busca as fontes do certificado no s3

        font_name_data = fetch_font_from_s3(
            bucket_certificate_name, certified_builder.FONT_NAME_PATH, s3)
        font_validation_data = fetch_font_from_s3(
            bucket_certificate_name, certified_builder.VALIDATION_CODE_PATH, s3)

        # Gera o certificado personalizado
        certificate_generated = certified_builder.generate_certificate(
            participant, certificate_template, font_name_data, font_validation_data)

        # Cria o nome do arquivo para o certificado
        file_name = certified_builder.create_name_file(participant)

        # Faz o upload do certificado gerado para o bucket S3
        upload_to_s3(certificate_generated, bucket_certificate_name, file_name)

        # Mensagem de sucesso personalizada
        return certificate_generated
    except Exception as e:
        raise
