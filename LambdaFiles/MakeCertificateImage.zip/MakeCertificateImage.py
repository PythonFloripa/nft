#\MakeCertificateImage-pop\MakeCertificateImage.py
import json
import boto3
import os
import hashlib
from datetime import datetime
import decimal
from io import BytesIO
from makeImage import makeImage


def ensure_utf8(obj):
    """
    Função recursiva para garantir que todas as strings em um objeto JSON
    estejam codificadas em UTF-8.
    """
    if isinstance(obj, dict):
        return {k: ensure_utf8(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [ensure_utf8(element) for element in obj]
    elif isinstance(obj, str):
        # Re-encode a string para bytes e decodifique novamente para garantir UTF-8
        return obj.encode('utf-8', errors='replace').decode('utf-8')
    else:
        return obj


def decimal_default(obj):
    """
    Função auxiliar para converter objetos Decimal em float.
    Usada no json.dumps para evitar erros de serialização.
    """
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    raise TypeError(
        f"Object of type {obj.__class__.__name__} is not JSON serializable")


# Inicialização dos recursos AWS
table_name = os.getenv('AWS_DYNAMODB_TABLE_TARGET_NAME_0')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(table_name)
sqs = boto3.client('sqs')
queue_url = os.getenv('AWS_SQS_QUEUE_SOURCE_URL_0')
bucket_certificate_name = os.environ.get('AWS_S3_BUCKET_TARGET_NAME_0')
bucket_template_name = os.environ.get('AWS_S3_BUCKET_TARGET_NAME_1')
s3 = boto3.client('s3')


def lambda_handler(event, context):
    """
    Função AWS Lambda para processar mensagens do SQS.
    Cada mensagem contém um payload JSON.
    """

    # Itera sobre cada registro no evento
    for record in event.get('Records', []):
        # Obtém o corpo da mensagem SQS
        message_body = record['body']
        print(f"Mensagem recebida: {message_body}")

        # Converte o corpo para JSON (assumindo que está formatado como JSON)
        message_json = json.loads(message_body)

        # Garante que todas as strings no JSON estejam em UTF-8
        message_json_utf8 = ensure_utf8(message_json)
        print("Mensagem JSON após garantir UTF-8:")
        print(json.dumps(message_json_utf8, indent=4, ensure_ascii=False))

        # Extração dos campos necessários
        OrgName = message_json_utf8.get("OrgName")
        EventName = message_json_utf8.get("EventName")
        AttendeeName = message_json_utf8.get("AttendeeName")
        AttendeeEmail = message_json_utf8.get("AttendeeEmail")
        SubID = message_json_utf8.get("SubID")

        if not all([OrgName, EventName, AttendeeName, AttendeeEmail, SubID]):
            print("Erro: Mensagem JSON está faltando um ou mais campos necessários.")
            continue  # Pular para a próxima mensagem

        # 1) GetItem da DynamoDB com Partition = OrgName e Sort = "#:" + EventName + ":" + SubID
        sort_key_item1 = f"#:{EventName}:{SubID}"
        print(
            f"Realizando GetItem com Partition={OrgName} e Sort={sort_key_item1}")
        response_get = table.get_item(
            Key={
                'Partition': OrgName,
                'Sort': sort_key_item1
            }
        )

        item1 = response_get.get('Item')
        if not item1:
            print(
                f"Item não encontrado na DynamoDB para Partition={OrgName} e Sort={sort_key_item1}")
            continue  # Pular para a próxima mensagem

        print("Item1 obtido da DynamoDB:")
        print(json.dumps(item1, indent=4,
                ensure_ascii=False, default=decimal_default))
        certificate_generated = makeImage(
            OrgName, EventName, AttendeeName, bucket_certificate_name, bucket_template_name, s3)

        # 2) PutItem com Partition = SubID, Sort = "#"+OrgName + DateTime (até minutos), atributo ObjectName
        current_time = datetime.utcnow().replace(second=0, microsecond=0)
        sort_key_item2 = f"#{OrgName}{current_time.strftime('%Y-%m-%dT%H:%M')}"
        object_name = f"{OrgName}-{EventName}-{SubID}-{current_time.strftime('%Y-%m-%dT%H:%M')}"
        print(
            f"Preparando PutItem com Partition={SubID}, Sort={sort_key_item2}, ObjectName={object_name}")

        table.put_item(
            Item={
                'Partition': SubID,
                'Sort': sort_key_item2,  # Corrigi a chave 'SortK' para 'Sort'
                'ObjectName': object_name
            }
        )
        print("PutItem realizado com sucesso para o item2.")

        # 3) Gerar um Hash de 512 bits do AttendeeName

        img_bytes = BytesIO()
        certificate_generated.save(img_bytes, format='PNG')
        img_bytes.seek(0)

        hash_object = hashlib.sha512(img_bytes.getvalue())
        attendee_hash = hash_object.hexdigest()
        print(
            f"Hash de 512 bits para AttendeeName ({AttendeeName}): {attendee_hash}")

        # 4) Atualizar Item1 com o campo "Hash" e PutItem na DynamoDB
        item1['Hash'] = attendee_hash
        print(f"Atualizando Item1 com o Hash: {item1}")

        table.put_item(
            Item=item1
        )
        print("PutItem atualizado com sucesso para o item1.")

