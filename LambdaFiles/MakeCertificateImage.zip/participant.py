import json
import random
import string



class Participant:
    def __init__(self, attendee_name, event_name, validation_code=None):
        self.attendee_name = attendee_name
        self.event_name = event_name
        self.validation_code = validation_code or self._generate_validation_code()

    @staticmethod
    def _generate_validation_code():
        """Gera um código de validação aleatório."""
        return ''.join(random.choices(string.hexdigits, k=9))

    def name_completed(self):
        """Formata o nome completo."""

        name_completed = self.attendee_name.lower()
        if len(name_completed.split(" ")) > 3:
            first_name = name_completed.split()[0]
            last_name = name_completed.split()[1] + " " + name_completed.split()[-1]
            name_completed = first_name + " " + last_name

        return name_completed.title()

    def formated_validation_code(self):
        """Formata o código de validação."""
        self.validation_code = self.validation_code.upper()
        return f"{self.validation_code[0:3]}-{self.validation_code[3:6]}-{self.validation_code[6:9]}"
